#Aditya Aparadh     22610082    S3
#Program to print name and age
print("Enter Name")
name = input()
print("Enter Age")
age = input()


print("Hello, ",name)
print("You are " + age +" years old")