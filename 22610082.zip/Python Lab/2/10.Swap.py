
#Aditya Aparadh     22610082    S3
#Program to swap two numbers
print("Enter First Number: ")
a = input()
print("Second Number: ")
b = input()

print("Before Swap-\n a =",a," b = ",b)

#Swap

temp = a
a = b
b = temp

print("After Swap-\n a =",a," b = ",b)