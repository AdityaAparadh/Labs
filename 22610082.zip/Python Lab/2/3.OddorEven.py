#Aditya Aparadh     22610082    S3
#Program to check if given number is even or odd
print("Input a number: ")
x = input()

if(int(x)%2 == 0):
    print(x + " is even")
else:
    print(x + " is odd")