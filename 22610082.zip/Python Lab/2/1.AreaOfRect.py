#Aditya Aparadh     22610082    S3
#Program to calculate area of rectangle
print("Enter Length and Width")

len = input()
wid = input()

print("Area is", len*wid)