#Aditya Aparadh     22610082    S3
#Program to check if given number is Positive or Negative
print("Enter a number")
i = input()
num = int(i)
if(num>0):
    print(num,"is a positive number")
elif(num<0):
    print(num,"is a negative number")
else:
    print(num,"is zero")