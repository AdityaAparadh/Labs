#Aditya Aparadh     22610082    S3
#Program to store name age and avg test score in variables
print("Enter Name")
name = input()
print("Enter Age")
age = input()
print("Enter Average Test Score")
average_test_score = input()

print("Name:",name)
print("Age:",age)
print("Average Test Score:", average_test_score)

