#Aditya Aparadh     22610082    S3
#Program to concatenate two strings
print("Enter First String: ")
one = input()
print("Enter Second String: ")
two = input()
three = one + two
print("Concatenated string: " + three)