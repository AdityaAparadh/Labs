#Aditya Aparadh     22610082    S3
#Program to demonstrate accessing element of a list 
fruits = ["apple", "banana", "mango", "pineapple", "strawberry"]
print("3rd Fruit: ", fruits[2])