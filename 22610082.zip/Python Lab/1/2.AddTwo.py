#Aditya Aparadh     22610082    S3
#Program to add two numbers
a = input()
b = input()

print(a+b)