#Aditya Aparadh     22610082    S3
#Program to print HELLO WORLD
print("HELLO WORLD!")