#Aditya Aparadh     22610082    S3
#Program to calculate area and circumference of Circle

print("Enter radius:")
r = input()
radius = float(r)
area = 3.14 * radius * radius
print("Area of circle is: ", area)
circumference = 2 * 3.14 * radius
print("Circumference of circle is: ", circumference)