#Aditya Aparadh     22610082    S3
#Program to convert minutes to hours and minutes

print("Enter minutes:")
minutes = input()
min = int(minutes)
hrs = min // 60
mins = min % 60

print("Hours:", hrs,"Minutes:", mins)

      