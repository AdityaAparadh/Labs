#Aditya Aparadh     22610082    S3
#Program to convert Celcius to Farenheit
print("Enter Temp in C- ")
celcius = input()
print("In Farenheit: ", (((float(celcius)*9)/5)+32))